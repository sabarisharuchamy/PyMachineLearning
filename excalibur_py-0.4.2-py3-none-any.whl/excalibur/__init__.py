# -*- coding: utf-8 -*-

from .__version__ import __version__
